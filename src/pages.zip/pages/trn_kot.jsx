      import React, { Component } from "react";
      import DynForms from "../components/dynForm";
      import EnhancedTable from "../components/dynTable";
      import Button from '@material-ui/core/Button';
      import TextField from '@material-ui/core/TextField';
      import Dialog from '@material-ui/core/Dialog';
      import DialogActions from '@material-ui/core/DialogActions';
      import DialogContent from '@material-ui/core/DialogContent';
      import DialogContentText from '@material-ui/core/DialogContentText';
      import DialogTitle from '@material-ui/core/DialogTitle';
      import PropTypes from 'prop-types';
      import { withStyles } from '@material-ui/core/styles';
      import Paper from '@material-ui/core/Paper';
      import Grid from '@material-ui/core/Grid';
      import Card from "@material-ui/core/Card";
      import CardActions from "@material-ui/core/CardActions";
      import CardContent from "@material-ui/core/CardContent";
import apiurl from "../helpers/apiurl";
      import Typography from "@material-ui/core/Typography";
      import Table from "@material-ui/core/Table";
      import TableBody from "@material-ui/core/TableBody";
      import TableCell from "@material-ui/core/TableCell";
      import TableHead from "@material-ui/core/TableHead";
      import TableRow from "@material-ui/core/TableRow";
      import Fab from '@material-ui/core/Fab';
      import AddIcon from '@material-ui/icons/Add';

      //**********************************************************
      //**************Dynamic Form Validation Schema**************

      // var t_name='trn_kot';    
      // var objkey={'desg_name':'','dept_id':''};
      // var objkey1={'desg_name':'','dept_id':''};
      // var validataions={'desg_name':'','dept_id':''}
      // var validataions1={'desg_name':'','dept_id':''}
      // var clearData={'desg_name':'','dept_id':''}
     

        //*****************Dynamic Table Schema*****************
const APIURL=apiurl;
        var tableSchema={fields:[
          {
            //................index first is static
            "key":"kot_id",
            "alias":"KOT ID" ,
            visible:false,
            queryValid:true
          },
          //...................
          
           {
            "key":"kot_no",
            "alias":"KOT NO" ,
            visible:true,
            queryValid:true
          },
          {
            "key":"fin_year",
            "alias":"Fin Year" ,
            visible:true,
            queryValid:true
          },

          {
            "key":"mas_service_type_service_name",
            "alias":"Service Name" ,
            visible:true,
            queryValid:false
          },
          
          {
            "key":"service_type_id",
            "alias":"service ID" ,
            "foreign_tbl":"mas_service_type",
            "foreign_fields":[{name:'service_type_id',alias:'value','alias1':'service_type_id'},{name:'service_name',alias:'value1','alias1':'service_name'}],
            visible:false,
            queryValid:true
          },
          {
            "key":"mas_employee_fname",
            "alias":"Employee Name" ,
            visible:true,
            queryValid:false
          },
          
          {
            "key":"emp_id",
            "alias":"Employee ID" ,
            "foreign_tbl":"mas_employee",
            "foreign_fields":[{name:'emp_id',alias:'value','alias1':'emp_id'},{name:'fname',alias:'value1','alias1':'fname'}],
            visible:false,
            queryValid:true
          },
          {
            "key":"mas_table_table_name",
            "alias":"Table Name" ,
            visible:true,
            queryValid:false
          },
          
          {
            "key":"table_id",
            "alias":"Table ID" ,
            "foreign_tbl":"mas_table",
            "foreign_fields":[{name:'table_id',alias:'value','alias1':'table_id'},{name:'table_name',alias:'value1','alias1':'table_name'}],
            visible:false,
            queryValid:true
          },
          {
            "key":"mas_outlet_outlet_name",
            "alias":"Outlet Name" ,
            visible:true,
            queryValid:false
          },
          
          {
            "key":"outlet_id",
            "alias":"Outlet ID" ,
            "foreign_tbl":"mas_outlet",
            "foreign_fields":[{name:'outlet_id',alias:'value','alias1':'outlet_id'},{name:'outlet_name',alias:'value1','alias1':'outlet_name'}],
            visible:false,
            queryValid:true
          },
          {
            "key":"persons",
            "alias":"Person" ,
            visible:true,
            queryValid:true
          },
          {
            "key":"mas_customer_fname",
            "alias":"Customer Name" ,
            visible:true,
            queryValid:false
          },
          
          {
            "key":"cust_id",
            "alias":"Customer ID" ,
            "foreign_tbl":"mas_customer",
            "foreign_fields":[{name:'cust_id',alias:'value','alias1':'cust_id'},{name:'fname',alias:'value1','alias1':'fname'}],
            visible:false,
            queryValid:true
          },
           {
            "key":"itemArrays", 
            "alias":"Item Array",
            "ismultiple":'yes',         
            visible:false,
            queryValid:false
          }
          ],table_name:'trn_kot',additonarrays:[{name:'trn_kot_items',keyvalue:'kot_id',title:'itemArrays'}]
        };


     var primary_key='kot_id';

           

          // ],table_name:t_name};


  //**************************************************************
  //**************************************************************

  var self=""
  class TrnKot extends Component {
    constructor(props) {
     console.log("props",props)
     super(props);
     this.state = {
      error: null,
      isLoaded: false,
      title:"Kot",
       tblValues:[],
      handleEditOpen:false,
      datas:props.editPopup,
      items: []
    };

  }
     //  //addPopup............

     //  handleClickOpen = (data) => {

     //   this.setState({ open: true });
     // };

     // handleClose = () => {
     //   this.setState({ open: false });
     //   this.setState({ handleEditOpen: false });
     //   objkey=Object.assign({},objkey1);
     //   validataions=Object.assign({},validataions1);
     // };

        //editPopup..........

        // handleClickEditOpen = (data) => {
        //   console.log("items",this.state.items)
        //   var items=this.state.items;

        //   var datakeys= Object.keys(data);
        //   var datavalues=Object.values(data);

        //   for (var i = 0; i< items.length; i++) {
        //     var getIndex=datakeys.indexOf(items[i].COLUMN_NAME);
        //     // items[i].value=datavalues[getIndex];
        //     objkey[items[i].COLUMN_NAME]=datavalues[getIndex];
        //     objkey[items[i].COLUMN_NAME]==""?validataions[items[i].COLUMN_NAME]="Field Required":validataions[items[i].COLUMN_NAME]=false;
        //   }
        //   this.setState({items});
        //   this.setState({ handleEditOpen: true });
          
        // };

        // handleEditClose = () => {
        //   this.setState({ handleEditOpen: false });
        // };


        // loadData = () =>{

        //   fetch('http://localhost:3001/api/v1/dynamicMaster/', {
        //     method: 'POST',
        //     headers: {
        //       Accept: 'application/json',
        //       'Content-Type': 'application/json',
        //     },
        //     body: JSON.stringify(mydata),
        //   }).then((response) => response.json())
        //   .then((responseJson) => {
        //     console.log("responseJsondynMas",responseJson);
        //     this.setState({items:responseJson})
        //   })

        // }
        // componentWillMount(){
        //   this.loadData()
        // }
        // insertDynMaster(data){
        //   var obj={fields:data,table_name:t_name};
        //   fetch('http://localhost:3001/api/v1/insertDyn', {
        //     method: 'POST',
        //     headers: {
        //       Accept: 'application/json',
        //       'Content-Type': 'application/json',
        //     },
        //     body: JSON.stringify(obj),
        //   }).then((response) => response.json())
        //   .then((responseJson) => {
        //     console.log("insertValues",responseJson);
        //     this.setState({insertValues:responseJson})
        //     this.loadTableData();

        //   })
        // }

        // updatetDynMaster(data){
        //   var obj={fields:data,table_name:t_name,primarykey:"kot_id"};
        //   fetch('http://localhost:3001/api/v1/updateDynamic', {
        //     method: 'POST',
        //     headers: {
        //       Accept: 'application/json',
        //       'Content-Type': 'application/json',
        //     },
        //     body: JSON.stringify(obj),
        //   }).then((response) => response.json())
        //   .then((responseJson) => {
        //     console.log("updateValues",responseJson);
        //     this.setState({updateValues:responseJson})
        //     this.loadTableData();

        //   })
        // }


        loadTableData =() =>{
          fetch(APIURL+'getDynApi', {
            method: 'POST',
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(tableSchema),
          }).then((response) => response.json())
          .then((responseJson) => {
            console.log("tblValuesKOt",responseJson);
            this.setState({tblValues:responseJson})

          })

        }

        // deleteDynMaster=(data) =>{

        //   console.log("deleteDynMaster",data);
        //   var obj={fields:data,table_name:t_name,primarykey:"kot_id"};
        //   fetch('http://localhost:3001/api/v1/deleteDyn', {
        //     method: 'POST',
        //     headers: {
        //       Accept: 'application/json',
        //       'Content-Type': 'application/json',
        //     },
        //     body: JSON.stringify(obj),
        //   }).then((response) => response.json())
        //   .then((responseJson) => {
        //     console.log("deleteValues",responseJson);

        //     this.loadTableData();

        //   })
        // }


        componentDidMount(){
          this.loadTableData();


        }
        // editonSubmit=(data) =>{
        //   console.log(" I am edited",data);
        //   // objkey=objkey1;
        //   // validataions=validataions1;
        //   this.updatetDynMaster(data);
        // }
        // onSubmit = (data) => {
        //   console.log('formChildrendata',data);
        //   this.insertDynMaster(data);
        // }



        render() {
          console.log("rendering");

          return (
            <div>
            <card>

           {/* <div style={{textAlign: "left"}}>
            <Fab color="primary" aria-label="Add" onClick={this.handleClickOpen} style={{
              margin: 13,backgroundColor:"#677c8c" }}>
              <AddIcon />
              </Fab>

              </div>*/}

              <EnhancedTable primaryKey={primary_key} tableTitel={this.state.title} tblDtatas={tableSchema.fields} tblDataValues={this.state.tblValues}  />

              <CardContent>
              <Typography variant="h5" component="h2">
              </Typography>
              </CardContent>
              </card>

             {/* <Dialog
              disableBackdropClick={true}
              disableEscapeKeyDown={true}
              open={this.state.open}
              onClose={this.handleClose}
              fullWidth={true}
              maxWidth="sm"
              aria-labelledby="form-dialog-title">
              <DialogTitle id="form-dialog-title"  style={{ backgroundColor: "#238fbd",color:"white"}}>Add {this.state.title}</DialogTitle>

              <DialogContent>
              <div classNmae="form-group"> 

              {this.state.items.length>0&&
                <DynForms primaryKey={primary_key} clearData={clearData} validataions={validataions} handleClose={this.handleClose} keys={objkey} formData={this.state.items}  onSubmit={this.onSubmit}/>
              }

              </div>

              </DialogContent>
              <DialogActions>
              </DialogActions>
              </Dialog>*/}
              
           {/*   <Dialog
              disableBackdropClick={true}
              disableEscapeKeyDown={true}
              open={this.state.handleEditOpen}
              onClose={this.handleEditClose}
              fullWidth={true}
              maxWidth="sm"
              aria-labelledby="form-dialog-title">
              <DialogTitle id="form-dialog-title" style={{ backgroundColor: "#238fbd",color:"white"}}>Edit {this.state.title}</DialogTitle>

              <DialogContent>
              <div classNmae="form-group"> 

              {this.state.items.length>0&&
                <DynForms  primaryKey={primary_key} clearData={clearData} validataions={validataions} handleClose={this.handleClose} keys={objkey} formData={this.state.items}  onSubmit={this.editonSubmit}/>
              }

              </div>

              </DialogContent>
              <DialogActions>
              </DialogActions>
              </Dialog>*/}


              </div>
              );


        }
      }

      export default TrnKot;
