 import React, { Component } from "react";
 import Button from '@material-ui/core/Button';
 import TextField from '@material-ui/core/TextField';
 import Dialog from '@material-ui/core/Dialog';
 import DialogActions from '@material-ui/core/DialogActions';
 import DialogContent from '@material-ui/core/DialogContent';
 import DialogContentText from '@material-ui/core/DialogContentText';
 import DialogTitle from '@material-ui/core/DialogTitle';
 import PropTypes from 'prop-types';
 import { withStyles } from '@material-ui/core/styles';
 import Paper from '@material-ui/core/Paper';
 import Grid from '@material-ui/core/Grid';
 import Card from "@material-ui/core/Card";
 import CardActions from "@material-ui/core/CardActions";
 import CardContent from "@material-ui/core/CardContent";
 import Table from "@material-ui/core/Table";
 import TableBody from "@material-ui/core/TableBody";
 import TableCell from "@material-ui/core/TableCell";
 import TableHead from "@material-ui/core/TableHead";
 import TableRow from "@material-ui/core/TableRow";
 import Input from '@material-ui/core/Input';
 import OutlinedInput from '@material-ui/core/OutlinedInput';
 import FilledInput from '@material-ui/core/FilledInput';
 import InputLabel from '@material-ui/core/InputLabel';
 import FormControl from '@material-ui/core/FormControl';
 import Select from '@material-ui/core/Select';
 import MenuItem from '@material-ui/core/MenuItem';
 import Fab from '@material-ui/core/Fab';
 import AddIcon from '@material-ui/icons/Add';
 import EnhancedTable from "../components/dynTable";
 import Tabs from '@material-ui/core/Tabs';
 import Tab from '@material-ui/core/Tab';
 import Typography from '@material-ui/core/Typography';
 import ItemComponent from "../components/itemComponent";
 import ItemRateComponent from "../components/itemRateComponent";
 import SwipeableViews from 'react-swipeable-views';
  import CancelOutlinedIcon from '@material-ui/icons/CancelOutlined';
   import apiurl from "../helpers/apiurl";


 function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 3 }}>
    {props.children}
    </Typography>
    );
}
const APIURL=apiurl;

//******************************
const styles = theme => ({
  root: {
   flexGrow: 1,
},
paper: {
   padding: theme.spacing.unit * 2,
   textAlign: 'center',
   color: theme.palette.text.secondary,
},
formControl: {
   margin: theme.spacing.unit,
   minWidth: 120,
},


});

  var tableSchema={fields:[
          {
            //................index first is static
            "key":"item_id",
            "alias":"Item ID" ,
            visible:false,
            queryValid:true
          },
          {
            //................index first is static
            "key":"item_code",
            "alias":"Item Code" ,
            visible:true,
            queryValid:true
          },
          {
            "key":"mas_category_category_name",
            "alias":"Category Name",
            visible:true,
            queryValid:false
          },
        
         
          {
            "key":"mas_group_group_name",
            "alias":"Group Name",
            visible:true,
            queryValid:false
          },
          {
            "key":"item_name",
            "alias":"Item Name" ,
            visible:true,
            queryValid:true
          },
          {
            "key":"item_desc",
            "alias":"Item Description" ,
            visible:true,
            queryValid:true
          },
          {
            "key":"item_cat_id",
            "alias":"Item ID" ,
            "foreign_tbl":"mas_category",
            "foreign_fields":[{name:'cat_id',alias:'cat_id','alias1':'cat_id'},{name:'category_name',alias:'category_name','alias1':'category_name'}],
            visible:false,
            queryValid:true
          },
          {
            "key":"group_id",
            "alias":"Item ID" ,
            "foreign_tbl":"mas_group",
            "foreign_fields":[{name:'grp_id',alias:'grp_id','alias1':'grp_id'},{name:'group_name',alias:'value','alias1':'group_name'}],
            visible:false,
            queryValid:true
          },
          {
            "key":"itemArrays", 
            "alias":"Item Array", 
            "ismultiple":'yes',         
            visible:false,
            queryValid:false
          },
          ],table_name:'mas_item',additonarrays:[{name:'mas_item_rate',keyvalue:'item_id',title:'itemArrays'}]
          };

var primary_key='item_id';
class ItemRateMasters extends Component {
  constructor(props) {
   console.log("props",props)
   var {keys}=props;
   super(props);
   this.state = {
    title:"Item",
    value:0,
    keys,
    itemEditData:[],
    tblValues:[],
    edit:false,
    unselectData:null

 };

}
  loadTableData =() =>{
    var self=this;
          fetch(APIURL+'getDynApi', {
            method: 'POST',
            headers: {
              Accept: 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(tableSchema),
          }).then((response) => response.json())
          .then((responseJson) => {
            console.log("tblValues",responseJson);
            this.setState({tblValues:responseJson})

          })

        }

        componentDidMount=() =>{
          console.log("loadingTableData");
          this.loadTableData();
        }
goback=() =>{
  this.setState({value:0});
}
handleClickOpen = (data) => {

   this.setState({ open: true });
};
onnext=() =>{

}

handleClose = () => {
   this.setState({ open: false });
   this.setState({edit:false});
   this.setState({value:0});
   this.setState({itemEditData:null})
   this.setState({unselectData:true})
   this.loadTableData();


       // this.setState({ handleEditOpen: false });
       // objkey=Object.assign({},objkey1);
       // validataions=Object.assign({},validataions1);
    };
onSubmit = (e) => {
        console.log("addDataItem",e)
        e.preventDefault();
        if(this.props.onSubmit) this.props.onSubmit(this.state.keys);
        this.handleClose();
    }
nextProceedData=(data) =>{
  this.setState({value:1});
  this.setState({itemData:data})

}
finalDataSent=(data) =>{
  console.log("itemrateResponse",data);
  console.log("itemrateResponse",this.state.edit);
  if(this.state.edit==false){

    fetch(APIURL+'insertItems/', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({data:data.finalResponse,date:new Date().getTime()}),
  }).then((response) => response.json())
    .then((responseJson) => {
        // console.log("response",responseJson);
        this.handleClose();

    })
  }else{
    data.finalResponse.item_id=this.state.itemEditData.item_id;
     fetch(APIURL+'updateItems/', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
      },
      body: JSON.stringify({data:data.finalResponse,date:new Date().getTime()}),
  }).then((response) => response.json())
    .then((responseJson) => {
        console.log("response",responseJson);
        this.handleClose();

    })
  }

}
handleClickEditOpen=(data) =>{
  console.log(data);
  this.setState({edit:true})
  this.handleClickOpen();
  this.setState({itemEditData:data});
}
    render() {
     console.log("rendering");
     console.log(this.state);

     return (
       <div>
       <card>
       <div style={{textAlign: "left"}}>
       <Fab color="primary" aria-label='Add' onClick={this.handleClickOpen} style={{
         margin: 13,backgroundColor:"#677c8c" }}>
         <AddIcon />
         </Fab>
         </div>
          <EnhancedTable unselectData={this.state.unselectData} primaryKey={primary_key} tableTitel={this.state.title} tblDtatas={tableSchema.fields} tblDataValues={this.state.tblValues} editOpen={this.handleClickEditOpen} DeleteData={this.deleteDynMaster}/>

         <CardContent>
         <Typography variant="h5" component="h2">
         </Typography>
         </CardContent>
         </card>

         <Dialog
         disableBackdropClick={true}
         disableEscapeKeyDown={true}
         open={this.state.open}
         onClose={this.handleClose}
         fullWidth={true}
         maxWidth="md"
         aria-labelledby="form-dialog-title">
         <DialogTitle id="form-dialog-title"  style={{ backgroundColor: "#238fbd",color:"white"}}>{this.state.edit==true?'Edit':'Add'} {this.state.title}<CancelOutlinedIcon onClick={this.handleClose} style={{cursor:'pointer',position:'absolute',right:12}}/></DialogTitle>
         <DialogContent>
         <div>

         <SwipeableViews index={this.state.value} >
         
         <TabContainer>
         <ItemComponent itemEditData={this.state.itemEditData} nextProceedData={this.nextProceedData}/></TabContainer>
         <TabContainer>
         <ItemRateComponent itemEditData={this.state.itemEditData} finalDataSent={this.finalDataSent} itemData={this.state.itemData} goback={this.goback} />
         
         </TabContainer>
         </SwipeableViews>
         </div>



         

         </DialogContent>

         <DialogActions>
         </DialogActions>
         </Dialog>

         </div>
         )
  }
}
export default ItemRateMasters;