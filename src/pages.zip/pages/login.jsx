import React, { Component } from "react";
import { NavLink, Link, Route, Redirect } from "react-router-dom";

import CardActions from "@material-ui/core/CardActions";

import {
  Card,
  TextField,
  Button,
  Typography,
  CardHeader
} from "@material-ui/core";
import { Fade, Zoom, Flip, Bounce } from "react-reveal";

import Dashboard from "./dashboard";
import Authentication from "./home";

const divStyle = {
  color: "blue",
  backgroundImage: "url(" + require("../images/loginmani.jpg") + ")",
  height: "100vh",
  width: "100vw",
  backgroundSize: "cover",
  position: "reltive"
};

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "edwin",
      password: "123"
    };
  }
  render() {
    return (
      <div
        style={divStyle}
        // style= {{}}
      >
        <Bounce top>
          <Card
            style={{
              minWidth: 300,
              // maxWidth: 800,
              // minHeight: 275,
              backgroundColor: "white",
              // background: "#6f565363",
              position: "absolute",
              // float: "right",
              top: "23vh",
              left: "65vw",
              // right: "8vw",
              width: "26vw",
              height: "60vh",
              backgroundColor:"#ffffff8c"
              // background: "rgb(169, 129, 113)"
            }}
          >
            <div>
              <Typography
                style={{
                  fontSize: 30,
                  backgroundColor: "black",
                  color: "white",
                  padding: 10
                }}
              >
                Admin Login
              </Typography>
              <div style={{ margin: 10 }}>
                <TextField
                  id="standard-password-input"
                  label="User Name"
                  // className={classes.textField}
                  type="Text"
                  margin="normal"
                  variant="outlined"
                  style={{ borderColor: "red", borderWidth: 10 }}
                />
              </div>
              <div>
                <TextField
                  id="standard-password-input"
                  label="Password"
                  // className={classes.textField}
                  type="password"
                  autoComplete="current-password"
                  margin="normal"
                  variant="outlined"
                />
              </div>
            </div>

            <NavLink
              to="/dashboard/department/"
              style={{ textDecoration: "none", color: "black" }}
            >
              <Button
                variant="contained"
                color="primary"
                style={{ margin: 15 }}
              >
                Login
              </Button>
            </NavLink>
            <Typography button>Fogot password?</Typography>
          </Card>
        </Bounce>

        {/* <div>
          <p style={{ float: "right", color: "White", fontSize: 100 }}>
            Welcome To The Restarent Management System
          </p>
        </div> */}
      </div>
    );
  }
}

export default Login;
