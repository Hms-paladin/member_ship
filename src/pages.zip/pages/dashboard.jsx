import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { withStyles } from "@material-ui/core/styles";
import {
  Typography,
  Divider,
  IconButton,
  ListItem,
  ListItemText,
  Collapse,
  Drawer,
  CssBaseline,
  AppBar,
  Toolbar,
  List,
  ListItemIcon
} from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import ChevronLeftIcon from "@material-ui/icons/ChevronLeft";
import ChevronRightIcon from "@material-ui/icons/ChevronRight";
import InboxIcon from "@material-ui/icons/MoveToInbox";
import MailIcon from "@material-ui/icons/Mail";
import SendIcon from "@material-ui/icons/Send";

import StarBorder from "@material-ui/icons/StarBorder";
import ExpandLess from "@material-ui/icons/ExpandLess";
import ExpandMore from "@material-ui/icons/ExpandMore";


import Login from "./login";
import EmpMaster from "./empMaster";

import { BrowserRouter, NavLink, Link, Switch, Route } from "react-router-dom";
import Authentication from "./home";

const drawerWidth = 270;

const hidestyle = {
  display: "none"
};

const menus = [


{
  id: 4,
  master: "Master",
  path: "/dashboard/master",
  icon: <SendIcon />,

  nested: [
  {
    id: 2,
    master: "Department",
    path: "/dashboard/department/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 3,
    master: "Designation",
    path: "/dashboard/designation/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 5,
    master: "Employee Type ",
    path: "/dashboard/emptype/",
    icon: <StarBorder />,
    nested: []
  },
  {
    id: 6,
    master: "Employee ",
    path: "/dashboard/employee/",
    icon: <StarBorder />,
    nested: [],
    menuStyles: { backgroundColor: "blue" }
  },
  {
    id: 9,
    master: "Outlet ",
    path: "/dashboard/outlet/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 10,
    master: "Group ",
    path: "/dashboard/group/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 11,
    master: "Category ",
    path: "/dashboard/category/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 12,
    master: "Service Type ",
    path: "/dashboard/servicetype/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 13,
    master: "Table ",
    path: "/dashboard/table/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 15,
    master: "Item",
    path: "/dashboard/ItemRate/",
    icon: <StarBorder />,
    nested: [],
  },
   {
    id: 17,
    master: "Settlement Type ",
    path: "/dashboard/settelmenttype/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 18,
    master: "Coupon",
    path: "/dashboard/coupon/",
    icon: <StarBorder />,
    nested: [],
  },
  //  {
  //   id: 19,
  //   master: "Company",
  //   path: "/dashboard/company/",
  //   icon: <StarBorder />,
  //   nested: [],
  // },
  {
    id: 19,
    master: "User",
    path: "/dashboard/user/",
    icon: <StarBorder />,
    nested: [],
  },
  {
    id: 20,
    master: "Customer",
    path: "/dashboard/Customer/",
    icon: <StarBorder />,
    nested: [],
  }
  ]
},
  {
    id: 21,
    master: "Transaction",
    path: "/dashboard/Customer/",
    icon: <StarBorder />,
    nested: [
    {
     id: 22,
    master: "KOT",
    path: "/dashboard/trn_kot/",
    icon: <StarBorder />,
    nested: []
  },
  // {
  //    id: 23,
  //   master: "Billing",
  //   path: "/dashboard/trn_settlement/",
  //   icon: <StarBorder />,
  //   nested: []
  // },
  {
     id: 24,
    master: "Settlements",
    path: "/dashboard/trn_settlement/",
    icon: <StarBorder />,
    nested: []
  }
  ]
  }

  
  
  
  ];
  const styles = theme => ({
    root: {
      display: "flex"
    },
    appBar: {
      zIndex: theme.zIndex.drawer + 1,
      transition: theme.transitions.create(["width", "margin"], {
        easing: theme.transitions.easing.sharp,
        duration: "0.6s"
      })
    },
    appBarShift: {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(["width", "margin"], {
        easing: theme.transitions.easing.sharp,
        duration: "0.6s"
      })
    },
    nested: {
      paddingLeft: 12
    },
    menuButton: {
      marginLeft: 12,
      marginRight: 20
    },
    hide: {
      display: "none"
    },
    drawer: {
      width: drawerWidth,
      flexShrink: 0
    },
    drawerPaper: {
      width: drawerWidth
    },
    drawerHeader: {
      display: "flex",
      alignItems: "center",
      padding: "0 8px",
      ...theme.mixins.toolbar,
      justifyContent: "flex-end"
    },

    drawerOpen: {
      width: drawerWidth,
      transition: theme.transitions.create("width", {
        easing: theme.transitions.easing.sharp,
        duration: "0.6s"
      })
    },
    drawerClose: {
      transition: theme.transitions.create("width", {
        easing: theme.transitions.easing.sharp,
        duration: "0.6s"
      }),
      overflowX: "hidden",
      width: theme.spacing.unit * 7 + 1,
      [theme.breakpoints.up("sm")]: {
        width: theme.spacing.unit * 9 + 1
      }
    },

    content: {
      flexGrow: 1,
      padding: theme.spacing.unit * 3
    },
    contentShift: {
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen
      }),
      marginLeft: 0
    }
  });

  class Dashboard extends React.Component {
    state = {
      open: true,
      sidemenu: menus,
      nestedmenu: false,
      windowHeight: "",
      windowWidth: "",
      hoverEffect: false,
      opened:true
    };

    hideshow = () => {
      this.setState({ show: true });
    };

    hoverOn = () => {
      this.setState({ open: true });

    };
    hoverOff = () => {
      this.setState({ open: false });
    };

    handleResize = () => {
      console.log(window.innerWidth);
      window.innerWidth <= 768
      ? this.setState({ open: false })
      : this.setState({ open: true });
    };

    componentDidMount() {
      this.handleResize();
      window.addEventListener("resize", this.handleResize);
    }

    componentWillUnmount() {
      window.removeEventListener("resize", this.handleResize);
    }

    nestedSideBar = item => {
      if (item.nested.length > 0) {
        this.setState({ open: true });
        var self=this;
    setTimeout(() =>{
      self.setState({opened:true});
    },500)
      }
    };

    nestedcheck = item => {
      console.log(item);
    // this.setState({ [item.master]: false });
    const { classes } = this.props;
    if (item.nested.length == 0) {
      return (
        <NavLink
        to={item.path}
        style={{
          textDecoration: "none",
          color: "white",
          background: "white"
        }}
        >
        <div style={{ paddingLeft: this.state.open==true?"8px":'0px', paddingRight: this.state.open==true?"8px":'0px' }}>
        <ListItem
        style={{
          paddingTop: "0px",
          paddingBottom: "3px"
                // paddingLeft: this.state.open == false ? "17px" : ""
              }}
              >
              <div
              style={{
                backgroundColor:
                this.state.open == false ? "rgba(200, 200, 200, 0.2)" : "",
                margin: "0px -19px",
                padding: "10px",
                width: "250px",
                borderRadius: "9px",
                textAlign: "center",
                textAlign: this.state.open == false ? "center" : "",
                display:this.state.open == false?"flex":'',
                justifyContent:this.state.open == false?"center":'',
                  // backgroundColor: "rgba(200, 200, 200, 0.2)"
                }}
                className={classes}
                >
                <ListItemIcon
                style={{
                  justifyContent: "center",
                  marginRight: "0px",
                  color: "white",
                  float: "left",
                  display:this.state.open == false?"flex":'',
                justifyContent:this.state.open == false?"center":'',
                }}
                >
                {item.icon}
                {this.state.opened == true && (
                  <ListItemText key={item.id}>
                  <div style={{ color: "white" }}>{item.master}</div>
                  </ListItemText>
                  )}
                </ListItemIcon>
                </div>
                </ListItem>
                </div>
                </NavLink>
                );
    }
    if (item.nested.length > 0) {
      // console.log(item.nested);

      return (
        <div
        style={{
          paddingLeft:this.state.open==true?"8px":'0px',
          paddingRight: this.state.open==true?"8px":'0px',

        }}
        >
      {/* <a style={{ backgroundColor: "yellow" }}> */}
      <ListItem
      onClick={() => this.handleClick(item.id)}
      style={{
        paddingTop: "0px",
        paddingBottom: "3px"

              // paddingLeft: this.state.open == false ? "17px" : ""/
            }}
            >
          {/* <ListItem> */}
          <div
          style={{
            backgroundColor:
            this.state.open == false ? "rgba(200, 200, 200, 0.2)" : "",
            margin: "0px -19px",
            padding: "10px",
            width: "250px",
            borderRadius: "9px",
            textAlign: this.state.open == false ? "center" : '',
            display:this.state.open == false?"flex":'',
            justifyContent:this.state.open == false?"center":'',
                // backgroundColor: "rgba(200, 200, 200, 0.2)"
              }}
              >
              <ListItemIcon
              onClick={() => this.nestedSideBar(item)}
              style={{
                marginRight: "0px",
                color: "white",
                float: "left",
                'display':this.state.open == false?"flex":'',
                justifyContent:this.state.open == false?"center":'',
              }}
              >
              {item.icon}
              </ListItemIcon>
              {this.state.opened == true && (
                <ListItemText key={item.id}>
                <div
                style={{
                  color: "white",
                  float: "left",
                  paddingLeft: "16px"
                }}
                >
                {" "}
                {item.master}
                </div>{" "}
                </ListItemText>
                )}

              {this.state.open == true ? (
                this.state[item.id] ? (
                  <ExpandLess
                  style={{
                     color: "white",
                        position: 'absolute',
                  right: '12px',

                  }}
                  />
                  ) : (
                  <ExpandMore
                  style={{
                    color: "white",
                        position: 'absolute',
                  right: '12px',
                  }}
                  />
                  )
                  ) : (
                  ""
                  )}
                  </div>
                  </ListItem>
                {/* </a> */}
                <Collapse in={this.state[item.id]} timeout="auto" unmountOnExit>
                <div component="div">
                {item.nested.length > 0 &&
                  item.nested.map(subitem => {
                    return (
                      <div
                      className={this.state.open == false ? "subComponent" : ""}
                      // style={{
                      //   paddingLeft: this.state.open == false ? "17px" : "",
                      //   color:""
                      // }}
                      >
                      {this.nestedcheck(subitem)}
                      </div>
                      );
                  })}
                  </div>
                  </Collapse>
                  </div>
                  );
    }
    return null;
  };

  handleDrawerOpen = () => {
    this.setState({ open: true });
    var self=this;
    setTimeout(() =>{
      self.setState({opened:true});
    },500)
  };

  handleDrawerClose = () => {
    this.setState({ open: false });
    this.setState({ opened: false });
  };

  handleClick = data => {
    this.setState(state => ({ [data]: !state[data] }));
  };

  render() {
    const { classes, theme } = this.props;
    const { open } = this.state;

    return (
      <div className={classes.root}>
      <CssBaseline />
      <AppBar
      position="fixed"
      className={classNames(classes.appBar, {
        [classes.appBarShift]: open
      })}
      style={{ background: "white" }}
      >
      <Toolbar
      disableGutters={!open}
      style={{ backgroundColor: "#238fbd"}}
      >
      <IconButton
      color="inherit"
      aria-label="Open drawer"
      onClick={this.handleDrawerOpen}
      className={classNames(classes.menuButton, open && classes.hide)}
      >
      <MenuIcon style={{ color: "black" }} />
      </IconButton>
      <Typography variant="h6" noWrap style={{ color: "white"}}>
      Restaurant Management System
      </Typography>
      </Toolbar>
      </AppBar>
      <div>
      <Drawer
      className={classes.drawer}
      variant="permanent"
      anchor="left"
      open={open}
      // onMouseOver={this.hoverOn}
      // onMouseLeave={this.hoverOff}
      classes={{
        paper: classes.drawerPaper
      }}
      className={classNames(classes.drawer, {
        [classes.drawerOpen]: open,
        [classes.drawerClose]: !open
      })}
      classes={{
        paper: classNames({
          [classes.drawerOpen]: open,
          [classes.drawerClose]: !open
        })
      }}
      >
      <div
      style={{
                
                backgroundSize: "cover",
                backgroundPosition: "cover cover",
                height: "100vh",
                overflowY: "auto",
                overflowX: "hidden",
                background:
                "linear-gradient(rgba(4, -7, 28, 0.38), rgba(87, 40, 62, 0.35)),url('https://images.pexels.com/photos/1236701/pexels-photo-1236701.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940') "
                
              }}
              >
              <div
              style={{
                position: "relative",
                textAlign: "center",
                fontSize: 20,
                float: "left",
                left: "100px",
                fontWeight: "20px",
                color: "white"
              }}
              >
              RMS
              </div>
              <div className={classes.drawerHeader}>
              <IconButton onClick={this.handleDrawerClose}>
              {theme.direction === "ltr" ? (
                <ChevronLeftIcon style={{ color: "white" }} />
                ) : (
                <ChevronRightIcon style={{ color: "white" }} />
                )}
                </IconButton>
                </div>
                <Divider
                style={{
                  background: "gray",
                  width: this.state.open == true ? "23vw" : "0vw",
                  position: "relative",
                  left: 12,
                }}
                />
              {/* {sideList} */}
              <a>
              <List>
              {this.state.sidemenu.map((items, i) => {
                return (
                  <div button key={i}>
                {/* <ListItemIcon>{items.icon}</ListItemIcon> */}
                {this.nestedcheck(items)}
                </div>
                );
              })}
              </List>
              </a>
              </div>
              </Drawer>
              </div>
              <main
               style={{width: 1000}}
              className={classNames(classes.content, {
                [classes.contentShift]: open
              })}
              >
              <div className={classes.drawerHeader} />
              <div style={{height:20}}>{this.props.children}</div>
              </main>
              </div>
              );
  }
}

Dashboard.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired
};

export default withStyles(styles, { withTheme: true })(Dashboard);
